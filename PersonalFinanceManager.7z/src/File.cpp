#include "File.h"
#include <string>
using namespace std;

File::File()
{

}

string File::getFilename()
{
    return filename;
}
